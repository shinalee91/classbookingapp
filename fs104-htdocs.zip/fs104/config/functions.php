<?php

function jsRedirect($url){
    echo "<script>window.location.href = '" . $url . "';</script>";
}

function jsAlert($text)
{
    echo "<script>alert('" . $text . "');</script>";
}

function isBlankField($data){
    if(trim($data) == "") {
        return true;
    } else {
        return false;
    }
}

function filterInput($data){
    $data = trim($data); #Removes unnecessary characters (spaces, tab, newline)
    $data = stripslashes($data); #Removes backslahses (\) from the user input data
    $data = htmlspecialchars($data); #replace HTML characters like < and > with &lt; and &gt;
    return $data;
}

function isValidEmail($email){
    //remove illgal characters
    $email = filter_var($email, FILTER_SANITIZE_EMAIL);
    //check if email format is valid 
    if(filter_var($email, FILTER_VALIDATE_EMAIL)){
        return true;
    } else {
        return false;
    }
}

function isValidName($name){
    if (preg_match("/^[a-zA-z]*$/", $name)) {
        return true;
    } else {
        return false;
    }
}

function isValidPhoneNumber($phone) {
    if (preg_match('/^[0-9]{8}+$/', $phone)) {
        return true;
    } else {
        return false;
    }
}

//Validate password input
function isValidPassword($password) {
    if (preg_match('/^[0-9]{8}+$/', $password)) {
        return true;
    } else {
        return false;
    }
}

function loggedIn() {
    if(isset($_COOKIE["studentName"]) && isset($_COOKIE["studentEmail"]) && isset($_COOKIE["studentPermission"])) {
        return true;
        jsRedirect(SITE_ROOT . "user-page.php");
    } else {
        if(isset($_SESSION["studentName"]) && isset($_SESSION["studentEmail"]) && isseT($_SESSION["studentPermission"])) { // Email and name session exists
            return true;
            jsRedirect(SITE_ROOT . "user-page.php");
        } else {
            return false;
            jsRedirect(SITE_ROOT . "index.php");

        }
    }
}

function loginCookies($studentName, $studentEmail, $studentPermission) {
    // store cookies
    setcookie("studentName", $studentName, time() + (86400 * 999));
    setcookie("studentEmail", $studentEmail, time() + (86400 * 999));
    setcookie("studentPermission", $studentPermission, time() + (86400 * 999));
}

function sessionLoggedIn($sessionID, $studentName, $studentEmail, $studentPermission) {
    $_SESSION["studentID"] = $studentID;
    $_SESSION["studentName"] = $studentName;
    $_SESSION["studentEmail"] = $studentEmail;
    $_SESSION["studentPermission"] = $studentPermission;
}


?>