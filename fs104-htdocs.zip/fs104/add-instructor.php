<?php
include "templates/admin-header.php";
$pageName = "Main Admin";   

if(!loggedIn()) {
    jsRedirect(SITE_ROOT . "index.php");
}

if(isset($_POST["add-btn"])) {  //when add button is clicked
// Filter input using filterInput function
    $inputInstructorName = filterInput($_POST["inputInstructorName"]);
    $inputInstructorEmail = filterInput($_POST["inputInstructorEmail"]);
    $inputInstructorEmail = filter_var($inputInstructorEmail, FILTER_SANITIZE_EMAIL);
    $inputInstructorPhone = filterInput($_POST["inputInstructorPhone"]);
    $inputInstructorIG = filterInput($_POST["inputInstructorIG"]);
    $inputBio = filterInput($_POST["inputBio"]);//
    
    //Validate inputs
    if(isBlankField($inputInstructorName || $inputInstructorEmail || $inputInstructorPhone || $inputInstructorIG || $inputBio)){
        jsAlert("Please fill up all fields.");
    } 
        else { // check if name is valid
                if(!isValidName($inputInstructorName)) {
                    jsAlert("Please enter a name.");
                } else { //check if email is valid
                    if(!isValidEmail($inputInstructorEmail)) {
                        jsAlert("Please enter a valid email.");
                    } else { //check if phone number is valid
                        if(!isValidPhoneNumber($inputInstructorPhone)) {
                            jsAlert("Please enter a phone number.");
                        } else { // check against DB if instructor exists
                            $newQuery = DB::query("SELECT * FROM Instructor WHERE instructorEmail=%?", $inputInstructorEmail);
                            $queryExists = DB::count();
                            if($queryExists){
                                jsAlert("Instructor has been added!");
                            } else { //insert to instructor DB
                                DB::insert('Instructor', [
                                    'instructorName' => $inputInstructorName,
                                    'instructorEmail' => $inputInstructorEmail,
                                    'instructorPhone' => $inputInstructorPhone,
                                    'instructorBio' => $inputBio,
                                    'instructorIG' => $inputInstructorIG,
                                ]);
                                $success=DB::affectedRows();
                                if($success){
                                    jsAlert("Instructor has been added!");
                                    jsRedirect(SITE_ROOT . "admin.php");
                                }

                            
                                }
                    }         
                }

            }
        }
}

?>

<body>
    <!-- Admin Nav Bar -->
    <div class="nav-box">
        <nav class="navbar navbar-expand-lg admin-nav-bar">
            <div class="container-fluid">
                <a class="navbar-brand" href="#">Admin Panel</a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                            <li class="nav-item">
                                <a class="nav-link active" aria-current="page" href="#">Home</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link active" aria-current="page" href="#">Instructors</a>
                            </li>
                            <!-- View user-page -->
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">Classes</a>
                                <ul class="dropdown-menu">
                                    <li><a class="dropdown-item disabled" href="#">Info</a></li>
                                    <li><a class="dropdown-item disabled" href="#">Schedules</a></li>
                                    <li><hr class="dropdown-divider"></li>
                                    <li><a class="dropdown-item  disabled" href="#">Book A Class</a></li>
                                </ul>
                            </li>

                            <!-- Admin management links -->
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">Management Links</a>
                                <ul class="dropdown-menu">
                                    <li><a class="dropdown-item" href="<?php SITE_ROOT ?>bookings.php">Bookings</a></li>
                                    <li><a class="dropdown-item disabled" href="#">Timetable</a></li>
                                    <li><hr class="dropdown-divider"></li>
                                    <li><a class="dropdown-item  disabled" href="#">Instructors</a></li>
                                </ul>
                            </li>
                            
                        </ul>
                        <button class="btn btn-sm" onclick="location.href='<?php echo SITE_ROOT . 'logout.php'?>';" id="admin-logout-btn" type="submit" name="logout">Logout</button>
                    </div>
            </div>
        </nav>
    </div>
    <!-- Admin Nav bar end -->
    <!-- Add instructor form -->

    <div class="container-fluid formbox m-3">
        <form method="POST">
            <div class="row">
                <div class="add-form col-md-3 my-2">
                <label for="inputInstructorName">Name</label>
                <input type="text" class="form-control me-2" name="inputInstructorName" placeholder="">
                </div>

                <div class="add-form col-md-3 my-2">
                <label for="inputInstructorEmail">Email</label>
                <input type="email" class="form-control me-2" name="inputInstructorEmail" placeholder="example@example.com">
                </div>

            </div>

            <div class="row">
                <div class="add-form col-md-3 my-2">
                <label for="inputInstructorPhone">Phone</label>
                <input type="text" class="form-control me-2" name="inputInstructorPhone" placeholder="9xxxxxxx">
                </div>

                <div class="add-form col-md-3 my-2">
                <label for="inputInstructorIG">IG Handle</label>
                <input type="text" class="form-control me-2" name="inputInstructorIG" placeholder="@ighandle">
                </div>
            </div>

            <div class="row align-items-end">
                <div class="add-form col-md-6 my-2">
                    <label for="inputBio">Bio</label>
                    <input type="text" class="form-control me-2" name="inputBio" placeholder="">
                </div>
            </div>
            
            <div class="add-form col-md-6 my-2">
                    <button type="submit" class="btn btn-sm" id="add-btn" name="add-btn">Add <i class="bi bi-person-plus-fill"></i></button>
            </div>
        </form>
    </div>
    <!-- Add instructor form -->

</body>
<?php include "templates/footer.php" ?>