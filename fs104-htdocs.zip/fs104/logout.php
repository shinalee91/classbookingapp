<?php
//include library files
include "config/config.php";
include "config/functions.php";
include "config/db.class.php";

//Check if student if logged in first

if(loggedIn()){
    if(isset($_COOKIE["studentName"]) && isset($_COOKIE["studentEmail"]) && isset($_COOKIE["studentPermission"])){
        //delete the cookie
        setcookie("studentName", "", time() - (86400 * 9999));
        setcookie("studentEmail", "", time() - (86400 * 9999));
        setcookie("studentPermission", "", time() - (86400 * 9999));
    } elseif(isset($_SESSION["studentName"]) && isset($_SESSION["studentEmail"]) && isset($_SESSION["studentPermission"])){ //email & name session exists
        //Clear & Destroy all sessions
        session_unset(); // remove all session variables
        session_destroy(); // destroy the session
    }  
    jsRedirect(SITE_ROOT . "index.php");
} else {
    jsRedirect(SITE_ROOT . "index.php");
}

?>
