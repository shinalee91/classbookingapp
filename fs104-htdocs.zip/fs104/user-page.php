<?php
include "templates/header.php";

$pageName = "user-page";
session_start();

if(!loggedIn()) {
    jsRedirect(SITE_ROOT . "index.php");
}

$curSeshQuery = DB::query("SELECT * FROM Student WHERE studentEmail=%s", $_SESSION["studentEmail"]);
$curStudentSesh = DB::count();
foreach($curSeshQuery as $getQueryResult){
    $curStudentSeshID = $getQueryResult["studentID"];
    $curStudentSeshName = $getQueryResult["studentName"];
    $curStudentSeshEmail = $getQueryResult["studentEmail"];
    $curStudentSeshPhone = $getQueryResult["studentPhone"];
    $curStudentSesh = $getQueryResult["studentPermission"];  
}


?>

<body>
    <?php include "templates/nav.php"; ?>
    <div class="container-fluid">
        <div class="row info-box my-3">

            <!-- Student Info -->
            <div class="card col col-sm-3 student-card">
                <div class="img my-3">
                    <img class="card-img-top mx-auto d-block" src="images/dancer3.png" style="width:50%" alt="Card image">
                </div>
                <div class="card-body text-center">
                    <h4 class="card-title"><?php echo $curStudentSeshName ?></h4>
                    <p class="card-text"><?php echo $curStudentSeshEmail ?></p>
                    <p class="card-text"><?php echo $curStudentSeshPhone ?></p>
                    <a href="#" type="submit" class="btn btn-sm" id="edit-btn">Edit Profile</a>
                    <a href="#" type="submit" class="btn btn-sm" id="cancel-btn">Cancel Classes</a>
                </div>
            </div>
            <!-- Student Info end -->   

            <!-- Table start --> 
            <div class="card col col-sm-8">
                <div class="card-body student-activity">
                    <!-- Table start -->
                    <div class="container mt-3 text-start">
                        <h3 class="card-title text-start">Hi <?php echo $curStudentSeshName ?>, here are your upcoming classes!</h3>
                        <p>A bunch of text.</p>            
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                <th>Class</th>
                                <th>Date / Time</th>
                                <th>{bookingStatus}</th>
                                </tr>
                            </thead>

                            <tbody>
                                <tr>
                                <td>{className}</td>
                                <td>{classStartDateTime}</td>
                                <td>{bookingStatus}</td>
                                </tr>
                                <tr>
                                <td>Mary</td>
                                <td>Moe</td>
                                <td>mary@example.com</td>
                                </tr>
                                <tr>
                                <td>July</td>
                                <td>Dooley</td>
                                <td>july@example.com</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div> 
            <!-- Table end --> 
        </div>
    </div>

    </body>
<?php include "templates/footer.php"; ?>
