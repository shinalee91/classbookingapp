<?php
    header("Content-type: text/css; charset: UTF-8"); 
?>

body {
    font-family: Poppins, sans-serif;
}

.header-box {
    height: 80px;
    width: 100%;
    background-color: #FFBD76;
    padding: 20px;
    justify-content: center;
    margin: 0px auto;
}

#edit-btn, #cancel-btn, #search-btn, #user-logout-btn, #login-button, #signup-button, #add-btn, #add-instructor, #book-class {
    background-color: #FFBD76;
}

.admin-header-box {
    height: 50px;
    width: 100%;
    background-color: #FF6464;
    justify-content: center;
    margin: 0px auto;
    padding-top: 8px;

}

@media screen and (max-width: 670px) {
  #admin-header-box {
    height: 100px; width: auto;
    overflow-wrap: break-all;
    }
}

.admin-nav-bar {
    background-color: #FF6464;
}

#admin-logout-btn {
    background-color: #F8FE85;
}

.site-header {
    font-family: Poppins, sans-serif;
    font-weight: 700;
    text-align: center;
    margin: auto;
    padding: 5px;
}

.admin-site-header {
    font-family: Poppins, sans-serif;
    font-weight: 400;
    text-align: left;
}


<!--Sidebar -->


<!--Sidebar End-->

.cards-container {
    margin-top: 20px;
    position: relative;
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    flex-direction: row;
}

.card {
    font-family: Poppins, sans-serif;
    font-weight: 400;
    justify-contents: center;
    text-align: center;
    width: 20rem;
    height: 20rem;
    margin: 10px auto 10px auto;
    position: relative;
}

label {
    font-size: 14px;
    font-weight: 400;
    margin: 5px;
}

::placeholder {
    font-size: 14px;
    font-weight: 400;

<!-- student card styling -->

.card .row {
    margin: 20px auto 10px auto;
    flex-direction: row;
    align-items: flex-start;
}

.activity-head {
    text-align: left;
    justify-content: left;
}

<!-- end of student card styling -->

footer-box {
    margin: 20px auto;
    padding: 5px;
    background-color: #FFBD76;
    font-family: Poppins, sans-serif;
    font-weight: 300;
    text-align: center;
    height: 40px;
}

