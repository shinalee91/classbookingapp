<?php
include "templates/header.php";
session_start();

$pageName = "signup";


//Query current loggedin student DB
$studentQuery = DB::query("SELECT * FROM Student WHERE studentID=%i", 1);
foreach($studentQuery as $userResult) {
    $studentName = $userResult["studentName"];
}

$newStudentName = $newStudentEmail = $newStudentPhone = $newStudentPassword = $confNewStudentPassword = "";

if (isset($_POST["signup"])){ //submit button clicked
//Filter input using filterInput function
    $newStudentName = filterInput($_POST["newStudentName"]);
    $newStudentEmail = filterInput($_POST["newStudentEmail"]);
    $newStudentEmail = filter_var($newStudentEmail, FILTER_SANITIZE_EMAIL);
    $newStudentPhone = filterInput($_POST["newStudentPhone"]);
    $newStudentPassword = filterInput($_POST["newStudentPassword"]);
    $confNewStudentPassword = filterInput($_POST["confNewStudentPassword"]);

    //Validate inputs
    if(isBlankField($newStudentName || $newStudentEmail || $newStudentPhone || $newStudentPassword || $confNewStudentPassword)){
        jsAlert("Please fill up all fields.");
    } else {
        if(!isValidName($newStudentName)){ // check if name is valid
            jsAlert("Please enter a name.");
        } 
        else {
            if(!isValidEmail($newStudentEmail)){ // check if email is valid
                jsAlert("Please enter a valid email.");
            } else {
                if(!isValidPhoneNumber($newStudentPhone)) 
                {
                    jsAlert("Please enter a phone number.");    
                } 
                else 
                {
                    if($newStudentPassword != $confNewStudentPassword){
                        jsAlert("Password & Confirm Password Mismatch");
                    } else {
                        $StudentQuery = DB::query("SELECT * FROM Student WHERE studentEmail=%?", $newStudentEmail);
                        $studentExist = DB::count();
                        if($studentExist){
                            jsAlert("Email already exists, please login.");
                            jsRedirect(SITE_ROOT);
                        } else { 
                            DB::insert('Student', [
                                'studentName' => $newStudentName,
                                'studentEmail' => $newStudentEmail,
                                'studentPhone' => $newStudentPhone,
                                'studentPassword' => $newStudentPassword,
                                'studentPermission' => 1,
                                'studentStatus'=> 1,
                            ]);
                            $success= DB::affectedRows();
                            if($success){
                                $curSeshQuery = DB::query("SELECT * FROM Student WHERE studentEmail=%s", $newStudentEmail);
                                $curStudentSesh = DB::count();
                                foreach($curSeshQuery as $getQueryResult){
                                    $curStudentSeshID = $getQueryResult["studentID"];
                                    $curStudentSeshName = $getQueryResult["studentName"];
                                    $curStudentSeshEmail = $getQueryResult["studentEmail"];
                                    $curStudentSeshPhone = $getQueryResult["studentPhone"];
                                    $curStudentSesh = $getQueryResult["studentPermission"];  
                                
                                    sessionLoggedIn($curStudentSeshName, $newStudentEmail, $getDBStudentPermission);
                                }
                                 // sessionLoggedIn($newStudentName, $newStudentEmail, $newStudentPhone);
                                jsRedirect(SITE_ROOT . "user-page.php");
                                } else {
                                    // jsRedirect("signup.php");
                                }
                            }
                        }
                    
                    }
                }
            }
    }
}
?>
<body>
    <div class="d-flex justify-content-around cards-container">
        <div class="card">
            <div class="card-body">
                    <h5 class="card-title">New here?</h5>
                    <p class="card-text">Create an account</p>
                    <!-- Registration Form-->
                        <form method="POST">
                            <div class="register-form mb-3">
                                <label for="studentName">Name</label>
                                <input type="text" class="form-control" name="newStudentName" placeholder="Your name here" value="<?php echo $newStudentName; ?>">
                                
                                <label for="studentEmail">Email address</label>
                                <input type="email" class="form-control" name="newStudentEmail" placeholder="name@example.com" value="<?php echo $newStudentEmail; ?>">
                                
                                <label for="studentPhone">Phone Number:</label>
                                <input type="text" class="form-control" name="newStudentPhone" placeholder="9xxxxxxx" value="<?php echo $newStudentPhone; ?>">
                                
                                <label for="studentPassword">Password</label>
                                <input type="password" class="form-control" name="newStudentPassword" placeholder="Enter password">
                                
                                <label for="studentPassword">Confirm Password</label>
                                <input type="password" class="form-control" name="confNewStudentPassword" placeholder="Confirm password">
                            </div>
                            <button type="submit" class="btn" name="signup" id="signup-button">Sign Up<i class="bi bi-hand-index-thumb"></i></button>
                        </form>
                    <!-- Registration Form End-->
            </div>
        </div>
    </div>
</body>        
<?php include "templates/footer.php"?>

