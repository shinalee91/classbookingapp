<?php
include "templates/admin-header.php";
$pageName = "Main Admin";   

if(!loggedIn()) {
    jsRedirect(SITE_ROOT . "index.php");
}


?>

<body>
    <!-- Admin Nav Bar -->
    <div class="nav-box">
        <nav class="navbar navbar-expand-lg admin-nav-bar">
            <div class="container-fluid">
                <a class="navbar-brand" href="#">Admin Panel</a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                            <li class="nav-item">
                                <a class="nav-link active" aria-current="page" href="#">Home</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link active" aria-current="page" href="#">Instructors</a>
                            </li>
                            <!-- View user-page -->
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">Classes</a>
                                <ul class="dropdown-menu">
                                    <li><a class="dropdown-item disabled" href="#">Info</a></li>
                                    <li><a class="dropdown-item disabled" href="#">Schedules</a></li>
                                    <li><hr class="dropdown-divider"></li>
                                    <li><a class="dropdown-item  disabled" href="#">Book A Class</a></li>
                                </ul>
                            </li>

                            <!-- Admin management links -->
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">Management Links</a>
                                <ul class="dropdown-menu">
                                    <li><a class="dropdown-item" href="<?php SITE_ROOT ?>bookings.php">Bookings</a></li>
                                    <li><a class="dropdown-item disabled" href="#">Timetable</a></li>
                                    <li><hr class="dropdown-divider"></li>
                                    <li><a class="dropdown-item  disabled" href="#">Instructors</a></li>
                                </ul>
                            </li>
                            
                        </ul>
                        <button class="btn btn-sm" onclick="location.href='<?php echo SITE_ROOT . 'logout.php'?>';" id="admin-logout-btn" type="submit" name="logout">Logout</button>
                    </div>
            </div>
        </nav>
    </div>
    <!-- Admin Nav bar end -->

    <!-- Page Content -->
    <div class="accordion accordion-flush" id="accordionExample">
        <div class="accordion-item">
            <h2 class="accordion-header" id="headingOne">
                <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                    Upcoming Classes
                </button>
            </h2>
            <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                <div class="accordion-body">
                    <!-- Accordion content goes here -->
                        <div class="container border rounded-top g-col-6 g-col-md-4 my-5 p-4">
                            <h2>Upcoming Classes</h2>
                            <p>Updated on <?php echo date("l, d-m-y") ?></p>
                            <table class="table table-sm table-group-divider">
                                <thead>
                                    <tr>
                                        <th scope="col">Time</th>
                                        <th scope="col">Class</th>
                                        <th scope="col">Instructor</th>
                                    </tr>
                                </thead>
                                
                                <tbody>
                                    <tr>
                                        <th scope="row">{classTime}</th>
                                        <td >{instructorEmail}</td>
                                        <td>{insturctorName}</td>
                                        </tr>
                                    <tr>
                                        <th scope="row">{classTime}</th>
                                        <td>{instructorEmail}</td>
                                        <td>{insturctorName}</td>
                                    </tr>
                                    <tr>
                                        <th scope="row">8.35pm</th>
                                        <td>K-Kardio Dance</td>
                                        <td>Jeslyn</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    <!-- End of accordion content -->
                </div>
            </div>
        </div>

        <div class="accordion-item">
            <h2 class="accordion-header" id="headingTwo">
                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                Recent Transactions
                </button>
            </h2>
            <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
                <div class="accordion-body">
                   <!-- Second accordion body -->
                        <div class="container border rounded-bottom g-col-6 my-5 p-4">
                            <table class="table table-sm table-group-divider table-responsive ">
                                <h2>Recent Transactions</h2>
                                <p>Last transaction:<?php echo date(" d-m-y") ?></p>
                                <thead>
                                    <tr>
                                        <th scope="col">Date/Time</th>
                                        <th scope="col">Name</th>
                                        <th scope="col">Class</th>
                                        <th scope="col">Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <tr>
                                    <th scope="row">{classTime}</th>
                                        <td >{instructorName}</td>
                                        <td>{instructorEmail}</td>
                                        <td>{instructorPhone}</td>
                                </tr>
                                <tr>
                                    <th scope="row">{classTime}</th>
                                        <td >{instructorName}</td>
                                        <td>{instructorEmail}</td>
                                        <td>{instructorPhone}</td>
                                </tr>
                                <tr>
                                    <th scope="row">{classTime}</th>
                                        <td >{instructorName}</td>
                                        <td>{instructorEmail}</td>
                                        <td>{instructorPhone}</td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                   <!-- End of accordion body -->
                </div>
            </div>
        </div>

        <div class="accordion-item">
            <h2 class="accordion-header" id="headingThree">
                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                Instructors
                </button>
            </h2>
            <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#accordionExample">
                <div class="accordion-body">
                    <!-- Third accordion body -->
                    <div class="container border rounded-bottom g-col-6 my-5 p-4">
                            <table class="table table-sm table-group-divider table-responsive ">
                                <h2>Instructors</h2>
                                <p>Last Updated: <?php echo date("l, d-m-y") ?></p>
                                <thead>
                                    <tr>
                                        <th scope="col">Name</th>
                                        <th scope="col">Email</th>
                                        <th scope="col">Phone</th>
                                        <th scope="col">IG Handle</th>
                                        <th scope="col">Bio</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $result = DB::query("SELECT * FROM Instructor");
                                    $checkResult = DB::count();
                                    foreach($result as $row){
                                        $resultName = $row["instructorName"];
                                        $resultEmail = $row["instructorEmail"];
                                        $resultPhone = $row["instructorPhone"];
                                        $resultIG = $row["instructorIG"];
                                        $resultBio = $row["instructorBio"];
                                    ?>  
    
                                <!-- For each loop to populate instructor info-->
                                    <tr>
                                        <th scope="row"><?php echo $resultName ?></th>
                                            <td><?php echo $resultEmail ?></td>
                                            <td><?php echo $resultPhone ?></td>
                                            <td><?php echo $resultIG ?></td>
                                            <td><?php echo $resultBio ?></td>
                                    </tr>
                                    <?php
                                        }
                                    ?>
                                </tbody>
                            </table>
                        <div class="add-form col-md-6 my-2">
                        <a href="add-instructor.php"><button type="button" class="btn btn-sm" id="add-instructor">Add instructor <i class="bi bi-person-plus-fill"></i></button></a>
                        </div>
                    </div>
                   <!-- End of accordion body -->
                </div>
            </div>
        </div>
    </div>

</body>

<?php include "templates/footer.php" ?>