<?php
include "templates/header.php";
session_start();

$pageName = "login";

$inputStudentEmail = $inputStudentPassword = "";

// $studentQuery = DB::query("SELECT * FROM Student WHERE studentID=%i", 1);
// foreach($studentQuery as $userResult) {
//     $studentName = $userResult["studentName"];
//     $studentEmail = $userResult["studentEmail"];
//     $studentPhone = $userResult["studentResult"];
//     $studentPassword = $userResult["studentPassword"];
//     $studentPermission = $userResult["studentPermission"];

// }


if(isset($_POST["login"]))
 //login button clicked
{
    //filter input using filterInput function
    $inputStudentEmail = filterInput($_POST["inputStudentEmail"]);
    $inputStudentPassword = filterInput($_POST["inputStudentPassword"]);
    // if(!isset($_POST['remember'])) {
    //     $remember = 0;
    // } else {
    //     $remember = 1;
    // }

    if($inputStudentEmail == "" || $inputStudentPassword == ""){
        jsAlert("Please enter a valid email or password.");
    } else {
        if(!isValidEmail($inputStudentEmail)){ //check if email is valid
            jsAlert("Please enter a valid email address.");
        } else {
        // check DB if student exists
        $getUserQuery = DB::query("SELECT * FROM Student WHERE studentEmail=%s", $inputStudentEmail);
        $userExist = DB::count(); // if user exist Both email and password exist
        foreach($getUserQuery as $getUserResult){
            $getDBStudentID = $getUserResult["studentID"];
            $getDBStudentName = $getUserResult["studentName"];
            $getDBStudentEmail = $getUserResult["studentEmail"];
            $getDBStudentPassword = $getUserResult["studentPassword"];
            $getDBStudentPermission = $getUserResult["studentPermission"];  
        }

        if($userExist) { //user exists (return 1)
        // Check if password is correct
            if($inputStudentPassword === $getDBStudentPassword){
            //true
                    loginCookies($getDBStudentName, $inputStudentEmail, $getDBStudentPermission);
                    sessionLoggedIn($getDBStudentID, $getDBStudentName, $inputStudentEmail, $getDBStudentPermission);
                    $queryStudentPerm = DB::query("SELECT * FROM Student WHERE studentEmail=%s", $inputStudentEmail);
                    foreach($queryStudentPerm as $queryResult){
                        $queryCurrPerm = $queryResult["studentPermission"];
                    }
                    if($queryCurrPerm == 2){
                        jsRedirect(SITE_ROOT . "admin.php");
                    } else {
                        jsRedirect(SITE_ROOT . "user-page.php");
                    }

                // store in sessions
                } else {
                    jsAlert("Invalid credentials. Please try again.");
                    jsRedirect(SITE_ROOT . "index.php");

                } 

            }

        

        }
    }


}

?>

    <body>
        <div class="col-md">
            <div class="card mb-3">
                <div class="card-body">
                    <h5 class="card-title"></h5>
                    <p class="card-text">Welcome back!</p>
                        <!--Login Form-->
                            <form method="POST">
                                <div class="login-form mb-3">
                                    <label for="inputStudentEmail">Email address</label>
                                    <input type="email" class="form-control mb-2" name="inputStudentEmail" placeholder="name@example.com">
                                    
                                    <label for="inputStudentPassword">Password</label>
                                    <input type="password" class="form-control" name="inputStudentPassword" placeholder="Password">
                                </div>
                                <!-- <div class="icheck-primary mb-2">
                                    <input type="checkbox" name="remember[]" id="remember" value="1">
                                    <label for="remember">
                                    Remember Me
                                    </label>
                                </div> -->
                                <div class="button mb-0">
                                    <button type="submit" class="btn btn-sm" name="login" id="login-button">Login <i class="bi bi-box-arrow-in-left"></i>></button>
                                </div>
                            </form><br>
                        <!--Login Form End-->
                    <span>New here?</span>
                    <span><a href="signup.php">Create an Account</a></span>
                </div>
            </div>
        </div>
    </body>
<?php include "templates/footer.php" ?>